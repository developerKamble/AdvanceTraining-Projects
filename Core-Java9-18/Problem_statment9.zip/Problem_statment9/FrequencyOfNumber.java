package com.Problem_statment9;

import java.util.HashMap;
import java.util.Map;

/*Given a sorted array containing duplicates, efficiently find frequency of each element in it without traversing the whole array.
 * Example Input:{2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 }
 * Example Output:  2 occurs 3 times
 * 4 occurs 3 times5 occurs 2 times	
 * 6 occurs 1 times8 occurs 2 times
 * 9 occurs 1 times*/
public class FrequencyOfNumber {
	static void findFreq(int arr[],int left,int right,Map<Integer,Integer> freq) {
		
		if(left>right) {
			return;
		}
		if(arr[left]==arr[right]) {
			Integer count=freq.get(arr[left]);
			System.out.println("*"+arr[left]);
			if(count==null) {
				count=0;
			}System.out.println("#"+count+(right-left+1));
			freq.put(arr[left], count+(right-left+1));
			return;
		}
		int mid=(right+left)/2;
		findFreq(arr,left,mid,freq);
		findFreq(arr,mid+1,right,freq);

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 };
		int count=0;
		Map<Integer,Integer> freq=new HashMap<>();
		
		findFreq(arr,0,arr.length-1,freq);
		
		System.out.println(freq);
	}

}
