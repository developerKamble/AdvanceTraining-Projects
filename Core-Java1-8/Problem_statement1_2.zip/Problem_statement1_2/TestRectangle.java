package com.coreproject2;

public class TestRectangle extends Rectangle {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Rectangle obj1=new Rectangle();
		
		obj1.setLength(20);
		obj1.setBreadth(10);
		
		System.out.println("Area of rectangle : "+obj1.areaOfRectangle()+" units"); 
	}

}
