package com.coreproject4;

import com.coreproject2.Rectangle;

/*
 * 1.4Modify the program, which is created in sub problem 1.2 as follows,
 * a.The class has attributes length and width, each of which defaults to 1.
 * b.It should have member functions that calculate the perimeter and area of the rectangle.
 * c.It should have set and get functions for both length and width.d.The set functions should  
 *   verify that length and width are each floating-point number larger than 0.0 and less than 20.0
 * */
public class Test2Rectangle extends Rectangle {

	
	Test2Rectangle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Rectangle obj = new Rectangle();
		obj.setLength(0);
		
	}

}
