package com.coreproject2;

public class Ointment implements MedicineInfo {
 
	public void displayLabel() {
		System.out.println("for external use only");
	}
}
