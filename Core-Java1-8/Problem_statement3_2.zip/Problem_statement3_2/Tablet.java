package com.coreproject2;

public class Tablet implements MedicineInfo {

	@Override
	public void displayLabel() {
		// TODO Auto-generated method stub
		System.out.println("store in a cool dry place");
	}

}
