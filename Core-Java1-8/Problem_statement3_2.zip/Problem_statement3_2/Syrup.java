package com.coreproject2;

public class Syrup implements MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("keep away from kids");
	}

}
